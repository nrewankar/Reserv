import UIKit

/*using classes*/
class userClass {
    var name : String
    var age : Int
    var city: String
    
    init(name: String, age: Int, city: String) {
        self.name = name
        self.age = age
        self.city = city
    }
    
}
var user1 = userClass(name: "Bob", age: 50, city: "Toronto")

func updateName(newName: String) -> String {
    user1.name = "\(newName)"
    return "\(user1.name)"
}

print("user's old name was \(user1.name) \nusers updated name is \(updateName(newName: "Benjamin"))")
