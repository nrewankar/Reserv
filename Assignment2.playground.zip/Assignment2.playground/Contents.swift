import UIKit


class Users {
    var name: String
    var yearOfBirth: Int
    var location: String
   
    /*initializes the Users super class*/
    init(name: String, yearOfBirth: Int, location: String) {
        self.name = name
        self.yearOfBirth = yearOfBirth
        self.location = location
        
    }
    
    /*functions for updating Users superclass info*/
    func updateName(newName: String) -> String{
        name = newName
        return "\(name)"
    }
    func updateyearOfBirth(newyearOfBirth: Int) -> Int {
        yearOfBirth = newyearOfBirth
        return yearOfBirth
    }
    func updateLocation(newLocation: String) -> String {
        location = newLocation
        return "\(location)"
    }
    
    /*subclass for username and password*/
    class userAccount: Users {
        var username: String
        var password: String
        
        init(name: String, yearOfBirth: Int, location: String, username: String, password: String) {
            self.username = username
            self.password = password
            
            super.init(name: name, yearOfBirth: yearOfBirth, location: location)
        }
        /*functions for updating username and password*/
        func updateUsername(newUsername: String) -> String {
            username = newUsername
            return "\(username)"
        }
        func updatePassword(newPassword: String) -> String {
            password = newPassword
            return "\(password)"
        }
    }
    
    /*could also have two accounts for the same user: eg. 1 user could have a family account and a personal account that have different preferences*/
    
    
    /*subclass with users food preferences within the Users super class*/
    class foodPreferences: Users {
        var foodPref1: String
        var foodPref2: String
        var foodPref3: String
        
        init(name: String, yearOfBirth: Int, location: String, foodPref1: String, foodPref2: String, foodPref3: String) {
            self.foodPref1 = foodPref1
            self.foodPref2 = foodPref2
            self.foodPref3 = foodPref3
            
            super.init(name: name, yearOfBirth: yearOfBirth, location: location)
        }
        /*function which returns the updated food preference and changes the prior value*/
        func updateFoodPreference(newPreference: String, preferenceNum: Int) -> String {
            switch preferenceNum{
            case 1: foodPref1 = newPreference
            case 2: foodPref2 = newPreference
            case 3: foodPref3 = newPreference
            default: print("restriction not found")
            }
            return "\(newPreference)"
        }
        
                                            // function which adds an extra food preference (3 is default for now)
        
    }
    
    /*food restrictions subclass within the Users super class*/
    class foodRestrictions: Users {
        var foodRestriction1: String
        var foodRestriction2: String
        var foodRestriction3: String
        
        init(name: String, yearOfBirth: Int, location: String, foodRestriction1: String, foodRestriction2: String, foodRestriction3: String){
            self.foodRestriction1 = foodRestriction1
            self.foodRestriction2 = foodRestriction2
            self.foodRestriction3 = foodRestriction3
            
            super.init(name: name, yearOfBirth: yearOfBirth, location: location)
        }
        
        /*function which returns updated food restriction and changes prior value*/
        func updateRestriction(newRestriction: String, restrictionNum: Int) -> String {
            switch restrictionNum{
            case 1: foodRestriction1 = newRestriction
            case 2: foodRestriction2 = newRestriction
            case 3: foodRestriction3 = newRestriction
            default: print("restriction not found")
            }
            return "\(newRestriction)"
        }
        
                                /*function which adds a food restriction (3 is the default fior now but could be any amount*/
        
    }
}


/*restaurants class - this is how users preferences will be linked to restaurants*/
class restaurants {
    //eg. dine in, drive thru, takeout
    var type: String
    
    //eg indian, chinese, fast food, etc.
    var genre: String
    
    // represents a price range which the user is comfortable with
    var lowerBoundCost: Int
    var upperBoundCost: Int
    
    // score based on user ratings
    var popularity: Int
    
    init(type: String, genre: String, lowerBoundCost: Int, upperBoundCost: Int, popularity: Int) {
        self.type = type
        self.genre = genre
        self.lowerBoundCost = lowerBoundCost
        self.upperBoundCost = upperBoundCost
        self.popularity = popularity
    }
}
